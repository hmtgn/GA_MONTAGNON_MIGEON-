# -*- coding: utf-8 -*-
"""
Created on Thu Feb 18 2022

@author: tdrumond & agademer

Template file for your Exercise 3 submission 
(GA solving TSP example)
"""
from ga_solver import GAProblem
import cities
import random

class TSProblem(GAProblem):
    def __init__(self, city_dict):
        self.city_dict = city_dict

    def create(self):

        return list(self.city_dict.keys())  
    
    def calculate_fitness(self, chromosome):
        total_distance = 0                                                                       
        for i in range(len(chromosome)):
            current_city = chromosome[i]
            next_city = chromosome[(i + 1) % len(chromosome)]                                    
            distance = cities.distance(self.city_dict[current_city], self.city_dict[next_city])  
            total_distance += distance                                                           
        return 1 / total_distance                                                                

    def reproduction(self, parent1, parent2):
        offspring = [-1] * len(parent1)                  
        start_pos = random.randint(0, len(parent1) - 1)  
        end_pos = random.randint(0, len(parent1) - 1)    
        if start_pos < end_pos:
            for i in range(start_pos, end_pos + 1):      
                offspring[i] = parent1[i]
        else:
            for i in range(end_pos, start_pos + 1):      
                offspring[i] = parent1[i]

        for i in range(len(parent2)):
            if parent2[i] not in offspring:
                for j in range(len(offspring)):
                    if offspring[j] == -1:
                        offspring[j] = parent2[i]        
                        break

        return offspring                                 

    def mutation(self, chromosome):
        pos1, pos2 = random.sample(range(len(chromosome)), 2)                    
        chromosome[pos1], chromosome[pos2] = chromosome[pos2], chromosome[pos1]  
        return chromosome  
    

    


if __name__ == '__main__':

    from ga_solver import GASolver
    file = "cities.txt"
    city_dict = cities.load_cities(file)
    problem = TSProblem(city_dict)
    solver = GASolver(problem)
    solver.reset_population()
    solver.evolve_until()
    cities.draw_cities(city_dict, solver.get_best_individual().chromosome) 
    solver.show_generation_summary()  
