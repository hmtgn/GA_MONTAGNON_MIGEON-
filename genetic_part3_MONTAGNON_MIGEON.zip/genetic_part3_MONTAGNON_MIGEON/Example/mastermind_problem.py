# -*- coding: utf-8 -*-
"""
Created on Thu Feb 18 2022

@author: tdrumond & agademer

Template file for your Exercise 3 submission 
(GA solving Mastermind example)
"""
from ga_solver import GAProblem  # Import the GAProblem class
import mastermind as mm  # Import the mastermind module
import random  # Import the random module


class MastermindProblem(GAProblem):
    """Implementation of GAProblem for the mastermind problem"""
    def __init__(self, match):
        """Initialize the MastermindProblem instance with a MastermindMatch object.
        
        Args:
            match (MastermindMatch): An object representing a Mastermind game match.
        """
        self.match = match  
    
    def __str__(self):
        """Return a string representation of the MastermindProblem object."""
        return f"MastermindProblem with match: {self.match}"  

    def mutation(self, chromosome):
        """Perform mutation operation on an individual's chromosome."""
        valid_colors = mm.get_possible_colors()                              # Get the list of possible colors
        pos = random.randrange(0, len(chromosome))                           # Generate a random position in the chromosome
        new_gene = random.choice(valid_colors)                               # Select a random color
        new_chromosome = chromosome[:pos] + [new_gene] + chromosome[pos+1:]  # Create a new chromosome with mutation
        return new_chromosome                                                # Return the mutated chromosome

    def create(self):
        """Generate a random chromosome."""
        return self.match.generate_random_guess() 

    def calculate_fitness(self, chromosome):
        """Calculate the fitness of an individual."""
        return self.match.rate_guess(chromosome)  

    def reproduction(self, parent1, parent2):
        """Perform crossover operation between parents' chromosomes."""
        x_point = random.randrange(0, len(parent1))             # Generate a random crossover point
        new_chromosome = parent1[:x_point] + parent2[x_point:]  # Create a new chromosome by combining parent chromosomes
        return new_chromosome                                   # Return the new chromosome


if __name__ == '__main__':

    from ga_solver import GASolver  # Import the GASolver class

    # Create a MastermindMatch object with a secret size of 6
    match = mm.MastermindMatch(secret_size=6)
    # Create a MastermindProblem instance with the match object
    problem = MastermindProblem(match)
    # Create a GASolver object with the problem instance
    solver = GASolver(problem)

    # Reset the population of the solver
    solver.reset_population()
    # Evolve the population until the problem is solved
    solver.evolve_until()
    # Get the best individual from the solver
    best = solver.get_best_individual()
    # Print the best guess
    print(f"Best guess {best.chromosome}")
    # Check if the problem is solved by comparing the best guess with the secret
    print(f"Problem solved? {match.is_correct(solver.get_best_individual().chromosome)}")
